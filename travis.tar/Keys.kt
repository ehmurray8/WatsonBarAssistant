package com.speakeasy.watsonbarassistant

const val ALGOLIA_API_KEY = "25064b61114ddb339dcdb42993bdd7a3"
const val ALGOLIA_APP_ID = "7WM50RUKFM"
const val ALGOLIA_SEARCH_KEY = "8060094f60aedb6e77e27016358255e6"